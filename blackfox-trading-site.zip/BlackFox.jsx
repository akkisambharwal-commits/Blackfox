import React, { useState, useEffect } from 'react';
import { initializeApp } from 'firebase/app';
import {
  getAuth,
  signInWithPopup,
  GoogleAuthProvider,
  onAuthStateChanged,
  signOut
} from 'firebase/auth';
import {
  getStorage,
  ref,
  uploadBytes,
  getDownloadURL
} from 'firebase/storage';
import {
  getFirestore,
  collection,
  addDoc,
  getDocs,
  query,
  orderBy
} from 'firebase/firestore';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_FIREBASE_AUTH_DOMAIN",
  projectId: "YOUR_FIREBASE_PROJECT_ID",
  appId: "YOUR_FIREBASE_APP_ID",
  storageBucket: "YOUR_FIREBASE_STORAGE_BUCKET"
};

const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const provider = new GoogleAuthProvider();
const db = getFirestore(app);
const storage = getStorage(app);

export default function BlackFox() {
  const [query, setQuery] = useState('');
  const [user, setUser] = useState(null);
  const [charts, setCharts] = useState([]);
  const [file, setFile] = useState(null);
  const [title, setTitle] = useState('');
  const [keywords, setKeywords] = useState('');

  const handleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, provider);
      setUser(result.user);
    } catch (error) {
      console.error(error);
    }
  };

  const handleLogout = () => {
    signOut(auth);
    setUser(null);
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (user) => {
      setUser(user);
    });
    return () => unsubscribe();
  }, []);

  useEffect(() => {
    const fetchCharts = async () => {
      const q = query(collection(db, 'charts'), orderBy('timestamp', 'desc'));
      const snapshot = await getDocs(q);
      const items = snapshot.docs.map(doc => doc.data());
      setCharts(items);
    };
    fetchCharts();
  }, []);

  const isAdmin = user?.email === 'akkisambharwal25@gmail.com';

  const filteredCharts = charts.filter(chart =>
    chart.title.toLowerCase().includes(query.toLowerCase()) ||
    chart.keywords.some(k => k.toLowerCase().includes(query.toLowerCase()))
  );

  const handleUpload = async () => {
    if (!file || !title || !keywords) return;
    const storageRef = ref(storage, `charts/${Date.now()}_${file.name}`);
    await uploadBytes(storageRef, file);
    const url = await getDownloadURL(storageRef);
    await addDoc(collection(db, 'charts'), {
      title,
      keywords: keywords.split(',').map(k => k.trim()),
      src: url,
      timestamp: new Date()
    });
    window.location.reload();
  };

  return (
    <div className="min-h-screen text-white font-sans bg-gradient-to-b from-black/80 via-purple-950/80 to-black/90 backdrop-blur-xl">
      <section className="h-screen flex flex-col justify-center items-center text-center px-4">
        <h1 className="text-6xl font-bold tracking-tight">BlackFox Trading</h1>
        <p className="mt-4 max-w-xl text-lg">Welcome to the universe of Smart Money Concepts – Explore premium XAU/USD trades, charts, and breakdowns by Shubham Sambharwal.</p>
        <div className="mt-6">
          {user ? (
            <div className="flex flex-col items-center gap-3">
              <p className="text-sm text-purple-300">Signed in as {user.displayName}</p>
              <Button onClick={handleLogout}>Logout</Button>
            </div>
          ) : (
            <Button onClick={handleLogin}>Sign in with Google</Button>
          )}
        </div>
      </section>

      {user && (
        <section id="gallery" className="py-16 px-4">
          <h2 className="text-4xl font-semibold text-center mb-8">📊 XAU/USD Chart Gallery</h2>
          <div className="max-w-3xl mx-auto mb-6 flex flex-col items-center gap-4">
            <Input placeholder="Search by keyword..." onChange={e => setQuery(e.target.value)} className="text-black" />
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-5xl mx-auto">
            {filteredCharts.map((chart, index) => (
              <Card key={index} className="bg-black/30 border border-purple-800">
                <CardContent className="p-4">
                  <img src={chart.src} alt={chart.title} className="rounded-lg mb-2" />
                  <h3 className="text-xl font-semibold">{chart.title}</h3>
                  <p className="text-sm opacity-75">#{chart.keywords.join(' #')}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </section>
      )}

      {isAdmin && (
        <section id="admin" className="py-16 px-4 bg-black/70">
          <h2 className="text-3xl font-semibold text-center mb-4">🛠 Admin Upload Panel</h2>
          <div className="max-w-2xl mx-auto flex flex-col gap-4">
            <Input type="file" onChange={e => setFile(e.target.files[0])} className="bg-white text-black" />
            <Input placeholder="Chart Title" onChange={e => setTitle(e.target.value)} className="text-black" />
            <Input placeholder="Keywords (comma separated)" onChange={e => setKeywords(e.target.value)} className="text-black" />
            <Button onClick={handleUpload}>Upload Chart</Button>
          </div>
        </section>
      )}

      <footer className="text-center py-8 text-white text-opacity-50 text-sm">
        CEO – Shubham Sambharwal
      </footer>
    </div>
  );
}
